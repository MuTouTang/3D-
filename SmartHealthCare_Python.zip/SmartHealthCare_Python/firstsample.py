import os
import matplotlib.pyplot as plt
import numpy as np
import SimpleITK as sitk
import cv2 as cv
import json

#python D:\PythonBase\SmartHealthCare_LJH\firstsample.py D:\SmartHealthCare.ASP\SmartHealthCare.ASP\SmartHealthCare.ASP\wwwroot\backend-test\test-models\0d60fa6b-4afc-40be-9480-c043bf254db1.nii.gz 50 D:\SmartHealthCare.ASP\SmartHealthCare.ASP\SmartHealthCare.ASP\wwwroot\backend-test\result-models -u
#python D:\PythonBase\SmartHealthCare_LJH\firstsample.py D:\PythonBase\SmartHealthCare_LJH\mini_set\label_Tr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz 50 D:\PythonBase\SmartHealthCare_LJH\Image_Save
def sample_read_and_save(sample_name, slice_id, save_path=None):
    """"""
    name = os.path.splitext(os.path.split(sample_name)[1].replace(".gz", ""))[0] + ".png"
    volume = sitk.GetArrayFromImage(sitk.ReadImage(sample_name))  # (82, 768, 768)
    sample_size = volume.shape
    sample_space = (1.0, 1.0, 1.0)

    sample_dict = {"sample_name": os.path.splitext(os.path.split(sample_name)[1].replace(".gz", ""))[0],
                   "file format": ".nii.gz",
                   "scan format": "CT",
                   "organ type": "腹部",
                   "sample size": sample_size,
                   "sample_space": sample_space}
    with open(os.path.join(save_path,"temp_info_dict.json"), "a") as f:
        f.write(str(sample_dict))
    # save to png
    if save_path:
        plt.imsave(os.path.join(save_path, name), volume[slice_id, :, :])
        print("image has been saved to ", os.path.join(save_path, name))
        plt.imsave("io_temp_slice.png", volume[slice_id, :, :])
    else:
        plt.imsave("io_temp_slice.png", volume[slice_id, :, :])

    return


if __name__ == '__main__':
    # python .\firstsample.py E:\Project\FuChuang_MedicalSeg\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz 50  C:\Users\Administrator
    # \Desktop
    # python .\firstsample.py E:\Project\FuChuang_MedicalSeg\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz 50

    import sys
    argv_list = sys.argv
    if len(argv_list) <= 3:
        sample_read_and_save(argv_list[1], int(argv_list[2]), None)
    else:
        sample_read_and_save(argv_list[1], int(argv_list[2]), argv_list[3])

    # sample_name = r"E:\Project\FuChuang_MedicalSeg\mini_set\label_Tr\77588f58-69e8-4a00-a974-95d967aa0429.nii.gz"     # sample_size (218, 512, 512) content_slice (94-217)
    # sample_name = r"E:\Project\FuChuang_MedicalSeg\mini_set\label_Tr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz"    # sample_size (251, 512, 512) content_slice (89-217)
    # sample_name = r"E:\Project\FuChuang_MedicalSeg\mini_set\label_Tr\0d60fa6b-4afc-40be-9480-c043bf254db1.nii.gz"       # sample_size (92, 512, 512) content_slice (41-91)

    # slice_id = 50
    # save_path = r"C:\Users\Administrator\Desktop"



    print("over!!")