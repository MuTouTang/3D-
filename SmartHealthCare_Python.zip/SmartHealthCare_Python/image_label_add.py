import os
import matplotlib.pyplot as plt
import numpy as np
import SimpleITK as sitk
import cv2 as cv
import json


def normlize(image):
    x_max = np.max(image)
    x_min = np.min(image)
    # x_std = np.std(image)
    # x_mean = np.mean(image)
    img = (image-x_min)/(x_max-x_min)
    # img = (image-x_mean)/(x_std)
    return img


def sample_image_label_add(sample_label_path, sample_image_path, slice_id, save_path=None):
    """
    该函数用于实现标签和样本的叠加显示（器官染色）
    """

    name = os.path.splitext(os.path.split(sample_image_path)[1].replace(".gz", ""))[0] + ".png"

    color_map = [(0, 238, 238),                (255, 228, 181),                (0, 238, 118),
                (106, 90, 205),                (0, 0, 255),                (0, 255, 255),                (255, 255, 0),
                (238, 180, 34),                (255, 106, 106),                (255, 69, 0),
                (255, 20, 147),                (205, 50, 120),                (30, 144, 255),
                (125, 38, 205),                (255, 130, 171),                (255, 106, 106)	,     (34, 139,34)]
    np.random.seed(1717)
    np.random.shuffle(color_map)
    color_map = [np.array(i)/255.0 for i in color_map]

    organ_label = ["left kidney",            "spleen",            "liver",            "arota",
                "stomach",            "gall bladder",            "postcava",            "duodenum",
                "right adrenal gland",	            "pancreas",	            "bladder",	            "esophagus",
                "left adrenal gland",	            "prostate/uterus",	            "right kidney"]
    organ_color = {"background": (0, 0, 0)}

    for i in range(15):
        organ_color[organ_label[i]] = color_map[i]

    image_volume = sitk.GetArrayFromImage(sitk.ReadImage(sample_image_path))  # (82, 768, 768)
    label_volume = sitk.GetArrayFromImage(sitk.ReadImage(sample_label_path))  # (82, 768, 768)
    image_volume = normlize(image_volume)
    image_slice = image_volume[np.newaxis, slice_id, :, :]
    label_slice = label_volume[np.newaxis, slice_id, :, :]

    image_slice = np.concatenate([image_slice, image_slice, image_slice], axis=0)#, dtype=np.float64

    sample_label_count = np.unique(label_slice)
    colorlize_image_slice = np.copy(image_slice)

    for organ_class in sample_label_count:
        if organ_class != 0:
            # ·plt.imshow(np.transpose(colorlize_image_slice*(1-(label_slice == organ_class)), (1, 2, 0)))
            # plt.show()

            colorlize_image_slice = colorlize_image_slice*(1-(label_slice == organ_class))    \
            + (label_slice == organ_class)*np.array(organ_color[organ_label[organ_class]])[:, np.newaxis, np.newaxis]
        else:
            colorlize_image_slice = image_slice

    colorlize_image_slice = np.transpose(colorlize_image_slice, (1, 2, 0))
    # # 测试接口
    # plt.subplot(131)
    # # plt.imsave("io_temp_slice.png", volume[slice_id, :, :], cmap="gray")
    # plt.imshow(image_volume[slice_id, :, :], cmap="gray")
    # plt.subplot(132)
    # # plt.imsave("io_temp_slice.png", volume[slice_id, :, :], cmap="gray")
    # plt.imshow(label_volume[slice_id, :, :], cmap="gray")
    # plt.subplot(133)
    # # plt.imsave("io_temp_slice.png", volume[slice_id, :, :], cmap="gray")
    # plt.imshow(colorlize_image_slice)
    # plt.show()

    # save to png
    if save_path:
        plt.imsave(os.path.join(save_path, name), colorlize_image_slice)
        print("image has been saved to ", os.path.join(save_path, name))
        plt.imsave("ila_color_slice.png", colorlize_image_slice)
    else:
        plt.imsave("ila_color_slice.png", colorlize_image_slice)

    return


if __name__ == '__main__':

    # python D:\PythonBase\SmartHealthCare_LJH\image_label_add.py D:\PythonBase\SmartHealthCare_LJH\mini_set\label_Tr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz D:\PythonBase\SmartHealthCare_LJH\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz 99 D:\PythonBase\SmartHealthCare_LJH\Image_Save
    # python D:\PythonBase\SmartHealthCare_LJH\image_label_add.py D:\SmartHealthCare.ASP\SmartHealthCare.ASP\SmartHealthCare.ASP\wwwroot\backend-test\test-labels\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz D:\SmartHealthCare.ASP\SmartHealthCare.ASP\SmartHealthCare.ASP\wwwroot\backend-test\test-models\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz 99 D:\SmartHealthCare.ASP\SmartHealthCare.ASP\SmartHealthCare.ASP\wwwroot\backend-test\result-adds
    import sys
    argv_list = sys.argv

    if len(argv_list) <= 4:
        sample_image_label_add(argv_list[1], argv_list[2], int(argv_list[3]), None)
    else:
        sample_image_label_add(argv_list[1], argv_list[2], int(argv_list[3]), argv_list[4])

    # sample_label_path = r"E:\Project\FuChuang_MedicalSeg\mini_set\labelTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz"     # sample_size (218, 512, 512) content_slice (94-217)
    # sample_image_path = r"E:\Project\FuChuang_MedicalSeg\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz"    # sample_size (251, 512, 512) content_slice (89-217)
    #
    # slice_id = 99
    # save_path = r"C:\Users\Administrator\Desktop"


    print("over!!")