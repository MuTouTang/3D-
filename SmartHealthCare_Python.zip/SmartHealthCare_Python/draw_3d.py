import SimpleITK as sitk
from skimage import measure, feature
from mayavi import mlab
import sys


def draw_3d(path, threshold):  # 路径, 阈值
    itk_img = sitk.ReadImage(path)
    img = sitk.GetArrayFromImage(itk_img)
    verts, faces, _, _ = measure.marching_cubes_lewiner(img, threshold)
    verts = verts.T
    # mlab.colorbar()
    mlab.triangular_mesh([verts[0]], [verts[1]], [verts[2]], faces)
    mlab.show()


if __name__ == '__main__':
    # python D:\PythonBase\SmartHealthCare_LJH\draw_3d.py  D:\PythonBase\SmartHealthCare_LJH\mini_set\ImageTr\0d60fa6b-4afc-40be-9480-c043bf254db1.nii.gz 150

    argv_list = sys.argv
    draw_3d(argv_list[1], int(argv_list[2]))

    print("over!!")