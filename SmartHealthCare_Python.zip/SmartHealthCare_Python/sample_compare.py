import os
import matplotlib.pyplot as plt
import numpy as np
import SimpleITK as sitk
import cv2 as cv
import json


def sample_slice_compare(sample_image_path1, sample_image_path2, slice_id1, slice_id2):
    """
    """

    name = os.path.splitext(os.path.split(sample_image_path1)[1].replace(".gz", ""))[0] + ".png"

    image_volume1 = sitk.GetArrayFromImage(sitk.ReadImage(sample_image_path1))  # (82, 768, 768)
    image_volume2 = sitk.GetArrayFromImage(sitk.ReadImage(sample_image_path2))  # (82, 768, 768)

    image_slice1 = image_volume1[slice_id1, :, :]
    image_slice2 = image_volume2[slice_id2, :, :]

    # # 测试接口
    plt.subplot(121).set_title(name.replace(".png", "") + " slice " + str(slice_id1))
    plt.imshow(image_slice1)
    plt.subplot(122).set_title(name.replace(".png", "") + " slice " + str(slice_id2))
    plt.imshow(image_slice2)

    plt.show()

    return


if __name__ == '__main__':

    # python D:\PythonBase\SmartHealthCare_LJH\sample_compare.py D:\PythonBase\SmartHealthCare_LJH\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz D:\PythonBase\SmartHealthCare_LJH\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz 99 96

    # import sys
    # argv_list = sys.argv
    # sample_image_path1 = argv_list[1]
    # sample_image_path2 = argv_list[2]
    #
    # slice_id1 = int(argv_list[3])
    # slice_id2 = int(argv_list[4])

    sample_image_path1 = r"D:\PythonBase\SmartHealthCare_LJH\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz"     # sample_size (218, 512, 512) content_slice (94-217)
    sample_image_path2 = r"D:\PythonBase\SmartHealthCare_LJH\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz"    # sample_size (251, 512, 512) content_slice (89-217)

    slice_id1 = 99
    slice_id2 = 96

    sample_slice_compare(sample_image_path1, sample_image_path2, slice_id1, slice_id2)
    print("over!!")