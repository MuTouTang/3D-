import os
import matplotlib.pyplot as plt
import numpy as np
import SimpleITK as sitk
import cv2 as cv
import json


def batch_sample_read_and_save(sample_name, save_path):
    """
    该函数用于将样本切分为png切片并保存
    """
    name = os.path.splitext(os.path.split(sample_name)[1].replace(".gz", ""))[0] + ".png"
    volume = sitk.GetArrayFromImage(sitk.ReadImage(sample_name))  # (82, 768, 768)
    sample_size = list(volume.shape)
    sample_space = [1.0, 1.0, 1.0]

    sample_dict = {"sample_name": os.path.splitext(os.path.split(sample_name)[1].replace(".gz", ""))[0],
                   "file format": ".nii.gz",
                   "scan format": "CT",
                   "organ type": "腹部",
                   "sample size": sample_size,
                   "sample_space": sample_space}

    with open(os.path.join("temp_info_dict.json"), "w") as f:
        f.write(str(sample_dict))

    if not os.path.exists(save_path):
        os.mkdir(save_path)
        print(save_path, " has been created!")
    if not os.path.exists(os.path.join(save_path, name.replace(".png", ""))):
        os.mkdir(os.path.join(save_path, name.replace(".png", "")))
        print(os.path.join(save_path, name.replace(".png", "")), " has been created!")

    # save to png
    for slice_id in range(sample_size[0]):
        plt.imsave(os.path.join(save_path, name.replace(".png", ""), name.replace(".png", "_"+str(slice_id)+".png")), volume[slice_id, :, :])
        print("image has been saved to ", os.path.join(save_path, name.replace(".png", ""), name.replace(".png", "_"+str(slice_id)+".png")))

    return


if __name__ == '__main__':
    # python D:\PythonBase\SmartHealthCare_LJH\batch_sample_io.py D:\PythonBase\SmartHealthCare_LJH\mini_set\ImageTr\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz D:\PythonBase\SmartHealthCare_LJH\Image_Save
    # python D:\PythonBase\SmartHealthCare_LJH\batch_sample_io.py D:\SmartHealthCare.ASP\SmartHealthCare.ASP\SmartHealthCare.ASP\wwwroot\backend-test\test-models\42547a6b-3f65-40a9-861c-bff502c90919.nii.gz D:\SmartHealthCare.ASP\SmartHealthCare.ASP\SmartHealthCare.ASP\wwwroot\backend-test\result-models
    import sys
    argv_list = sys.argv
    # python D:\PythonBase\SmartHealthCare_LJH\batch_sample_io.py D:\PythonBase\SmartHealthCare_LJH\mini_set\pred_samples2\0d60fa6b-4afc-40be-9480-c043bf254db1.nii.gz D:\PythonBase\SmartHealthCare_LJH\Image_Save

    # sample_name = r"E:\Project\FuChuang_MedicalSeg\system_func\mini_set\ImageTr\0d60fa6b-4afc-40be-9480-c043bf254db1.nii.gz"       # sample_size (92, 512, 512) content_slice (41-91)

    # 切片文件保存在temp_slice_box\样本名\目录下
    batch_sample_read_and_save(argv_list[1], argv_list[2])

    print("over!!")